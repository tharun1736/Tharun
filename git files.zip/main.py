"""Star Catcher: steer the basket with your hand.
Open palm = play | Fist = pause | Pinch = start/restart | Q/Esc = quit"""
import argparse, random, time
import cv2
import pygame
import db
from presence import PresenceMonitor, PLAYING, IDLE, AWAY
from vision import Tracker, normalize_lighting

W, H, AWAY_END = 640, 480, 15.0   # seconds AWAY before the session is ended


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--player", default="Player")
    ap.add_argument("--camera", type=int, default=0)
    args = ap.parse_args()

    conn = db.connect(); db.init(conn)
    pid = db.get_or_create_player(conn, args.player)   # validated + parameterized

    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise SystemExit("Cannot open camera")
    tracker, monitor = Tracker(), PresenceMonitor()

    pygame.init()
    screen = pygame.display.set_mode((W, H))
    font = pygame.font.SysFont(None, 32)
    clock = pygame.time.Clock()

    score, lives, items, running, away_since, frame_n, face = 0, 3, [], False, None, 0, False
    last_spawn, bx, status = 0.0, 0.5, None

    def save(s):
        if score > 0 or running:
            db.save_score(conn, pid, score, s)

    while True:
        dt = clock.tick(30) / 1000
        now = time.time()
        for e in pygame.event.get():
            if e.type == pygame.QUIT or (e.type == pygame.KEYDOWN and e.key in (pygame.K_q, pygame.K_ESCAPE)):
                save("finished"); return

        ok, frame = cap.read()
        if not ok:
            continue
        frame = normalize_lighting(cv2.flip(frame, 1))
        hand = tracker.hand(frame)
        frame_n += 1
        if not hand.present and frame_n % 5 == 0:      # face check is costlier, so throttle it
            face = tracker.face_present(frame)
        elif hand.present:
            face = True
        state = monitor.update(now, hand.present, hand.x if hand.present else None,
                               face and not hand.present)

        if hand.present:
            bx = hand.x
        paused_by_fist = hand.present and hand.gesture == "FIST"
        if hand.present and hand.gesture == "PINCH" and not running:
            running, score, lives, items = True, 0, 3, []

        # Presence handling
        if state == AWAY:
            away_since = away_since or now
            if running and now - away_since > AWAY_END:
                save("left"); running = False
        else:
            away_since = None
        active = running and state == PLAYING and not paused_by_fist

        if active:
            if now - last_spawn > 0.8:
                last_spawn = now
                items.append([random.random(), 0.0, random.random() < 0.25])  # x, y, is_bomb
            for it in items:
                it[1] += dt * 0.35
            for it in items[:]:
                if it[1] > 0.9:
                    items.remove(it)
                    if abs(it[0] - bx) < 0.1:
                        if it[2]: lives -= 1
                        else: score += 10
            if lives <= 0:
                save("finished"); running = False

        # Draw
        screen.fill((15, 15, 30))
        for x, y, bomb in items:
            pygame.draw.circle(screen, (220, 40, 40) if bomb else (255, 220, 0), (int(x * W), int(y * H)), 12)
        pygame.draw.rect(screen, (80, 200, 255), (int(bx * W) - 50, H - 30, 100, 16))
        msg = {PLAYING: "", IDLE: "Are you there? Paused (idle)", AWAY: "Player left. Paused"}[state]
        if not running: msg = "Pinch to start"
        elif paused_by_fist: msg = "Paused (fist)"
        screen.blit(font.render(f"Score {score}  Lives {lives}  [{state}]", True, (255, 255, 255)), (10, 10))
        if msg: screen.blit(font.render(msg, True, (255, 150, 150)), (10, 45))
        for i, (n, s) in enumerate(db.top_scores(conn, 3)):
            screen.blit(font.render(f"{i+1}. {n} {s}", True, (180, 255, 180)), (W - 200, 10 + 28 * i))
        thumb = cv2.cvtColor(cv2.resize(frame, (160, 120)), cv2.COLOR_BGR2RGB)
        screen.blit(pygame.image.frombuffer(thumb.tobytes(), (160, 120), "RGB"), (W - 170, H - 130))
        pygame.display.flip()


if __name__ == "__main__":
    main()
