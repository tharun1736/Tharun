# Gesture Star Catcher

Webcam game controlled by your hand. Catch stars, dodge bombs.

## Features
- **Hand control** via MediaPipe landmarks (no skin-colour thresholds, so it works across skin tones and backgrounds)
- **Lighting robustness**: auto-gamma + CLAHE on the luminance channel before detection
- **Presence detection**: `PLAYING` / `IDLE` (face visible but no hand, or hand frozen too long) / `AWAY` (no hand, no face). Game auto-pauses; session is saved as `left` after 15s away
- **SQL-injection safe**: parameterized queries only, allow-list input validation, and DB `CHECK` constraints

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python main.py --player Alice
pytest
```

## Controls
Pinch = start | Open palm = play | Fist = pause | Q/Esc = quit

## Tuning
Thresholds live in `presence.py` (`idle_after`, `away_after`, `hand_grace`).
