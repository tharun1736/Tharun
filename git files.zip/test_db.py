import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pytest, db

@pytest.fixture
def conn():
    c = db.connect(":memory:"); db.init(c); return c

def test_injection_names_rejected(conn):
    for bad in ["x'; DROP TABLE scores;--", "' OR '1'='1", "a\"b", "a;b"]:
        with pytest.raises(ValueError):
            db.get_or_create_player(conn, bad)
    conn.execute("SELECT 1 FROM scores")  # table still exists

def test_save_and_rank(conn):
    pid = db.get_or_create_player(conn, "Alice")
    db.save_score(conn, pid, 120, "finished")
    assert db.top_scores(conn)[0] == ("Alice", 120)

def test_bad_score_status(conn):
    pid = db.get_or_create_player(conn, "Bob")
    with pytest.raises(ValueError): db.save_score(conn, pid, "1; DROP TABLE x", "finished")
    with pytest.raises(ValueError): db.save_score(conn, pid, 5, "hacked")
