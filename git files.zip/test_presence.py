import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from presence import PresenceMonitor, PLAYING, IDLE, AWAY

def test_flow():
    m = PresenceMonitor()
    assert m.update(0, True, 0.2) == PLAYING
    assert m.update(1, True, 0.5) == PLAYING
    assert m.update(5, False, None, True) == IDLE      # face only
    assert m.update(20, False, None, False) == AWAY    # nobody
    assert m.update(21, True, 0.5) == PLAYING

def test_frozen_hand_goes_idle():
    m = PresenceMonitor(idle_after=5)
    m.update(0, True, 0.5)
    for t in range(1, 8): s = m.update(t, True, 0.5)
    assert s == IDLE
