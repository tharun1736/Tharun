"""SQLite storage. EVERY query is parameterized; user input is never concatenated into SQL.
Inputs are also validated (allow-list), as a second layer of defence."""
import re
import sqlite3
from contextlib import closing

NAME_RE = re.compile(r"^[A-Za-z0-9_ \-]{1,16}$")
MAX_SCORE = 1_000_000
STATUSES = {"finished", "idle_timeout", "left"}


def connect(path="scores.db"):
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init(conn):
    with conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS players(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE CHECK(length(name) BETWEEN 1 AND 16));
        CREATE TABLE IF NOT EXISTS scores(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player_id INTEGER NOT NULL REFERENCES players(id),
            score INTEGER NOT NULL CHECK(score BETWEEN 0 AND 1000000),
            status TEXT NOT NULL CHECK(status IN ('finished','idle_timeout','left')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);""")


def validate_name(name):
    if not isinstance(name, str) or not NAME_RE.fullmatch(name.strip()):
        raise ValueError("Name must be 1-16 chars: letters, digits, space, _ or -")
    return name.strip()


def get_or_create_player(conn, name):
    name = validate_name(name)
    with conn:
        conn.execute("INSERT OR IGNORE INTO players(name) VALUES (?)", (name,))
    with closing(conn.execute("SELECT id FROM players WHERE name = ?", (name,))) as cur:
        return cur.fetchone()[0]


def save_score(conn, player_id, score, status):
    if not isinstance(score, int) or isinstance(score, bool) or not 0 <= score <= MAX_SCORE:
        raise ValueError("Invalid score")
    if status not in STATUSES:
        raise ValueError("Invalid status")
    with conn:
        conn.execute("INSERT INTO scores(player_id, score, status) VALUES (?, ?, ?)",
                     (player_id, score, status))


def top_scores(conn, limit=5):
    limit = max(1, min(int(limit), 100))
    with closing(conn.execute(
            "SELECT p.name, MAX(s.score) AS best FROM scores s "
            "JOIN players p ON p.id = s.player_id GROUP BY p.id ORDER BY best DESC LIMIT ?",
            (limit,))) as cur:
        return cur.fetchall()
