"""Lighting normalization + hand/face tracking."""
from dataclasses import dataclass
import cv2
import numpy as np
import mediapipe as mp

_clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))


def normalize_lighting(frame):
    """Auto-gamma toward mid brightness, then CLAHE on luminance only.
    Helps in dim rooms, backlight and harsh lamps without shifting colours."""
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    mean = float(np.clip(l.mean() / 255.0, 0.05, 0.95))
    gamma = float(np.clip(np.log(0.5) / np.log(mean), 0.4, 2.5))
    lut = ((np.arange(256) / 255.0) ** gamma * 255).astype("uint8")
    l = _clahe.apply(cv2.LUT(l, lut))
    return cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)


@dataclass
class HandState:
    present: bool = False
    x: float = 0.5          # 0..1, mirrored so moving right moves right
    gesture: str = "NONE"   # OPEN | FIST | PINCH | OTHER | NONE
    landmarks: object = None


def _d(p, q):
    return float(np.hypot(p.x - q.x, p.y - q.y))


def classify(lm):
    """Rotation/scale-invariant gesture from landmark distances (no skin colour used)."""
    wrist, palm = lm[0], max(_d(lm[0], lm[9]), 1e-6)
    ext = sum(_d(lm[t], wrist) > _d(lm[p], wrist) * 1.1
              for t, p in ((8, 6), (12, 10), (16, 14), (20, 18)))
    if _d(lm[4], lm[8]) / palm < 0.35:
        return "PINCH"
    if ext >= 3:
        return "OPEN"
    if ext <= 1:
        return "FIST"
    return "OTHER"


class Tracker:
    def __init__(self, smooth=0.5):
        self.hands = mp.solutions.hands.Hands(
            max_num_hands=1, min_detection_confidence=0.5, min_tracking_confidence=0.5)
        self.face = mp.solutions.face_detection.FaceDetection(
            model_selection=0, min_detection_confidence=0.5)
        self.smooth, self._x = smooth, 0.5

    def hand(self, frame_bgr):
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        res = self.hands.process(rgb)
        if not res.multi_hand_landmarks:
            return HandState()
        hl = res.multi_hand_landmarks[0]
        lm = hl.landmark
        raw = (lm[0].x + lm[9].x) / 2
        self._x += self.smooth * (raw - self._x)       # EMA smoothing
        return HandState(True, self._x, classify(lm), hl)

    def face_present(self, frame_bgr):
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        return bool(self.face.process(rgb).detections)
