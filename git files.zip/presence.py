"""Decides whether the player is PLAYING, IDLE (present but not playing), or AWAY (left)."""
PLAYING, IDLE, AWAY = "PLAYING", "IDLE", "AWAY"


class PresenceMonitor:
    def __init__(self, hand_grace=1.0, idle_after=10.0, away_after=8.0, motion_eps=0.01):
        self.hand_grace, self.idle_after = hand_grace, idle_after
        self.away_after, self.motion_eps = away_after, motion_eps
        self.last_hand = self.last_face = self.last_motion = None
        self._last_x = None
        self._start = None

    def update(self, now, hand_present, hand_x=None, face_present=False):
        if self._start is None:
            self._start = self.last_hand = self.last_face = self.last_motion = now
        if hand_present:
            if now - self.last_hand > self.hand_grace:
                self.last_motion = now                 # hand just (re)appeared
            self.last_hand = self.last_face = now      # a hand implies a person
            if hand_x is not None:
                if self._last_x is None or abs(hand_x - self._last_x) > self.motion_eps:
                    self.last_motion = now
                self._last_x = hand_x
        elif face_present:
            self.last_face = now
        return self.state(now)

    def state(self, now):
        if now - self.last_hand <= self.hand_grace:
            # hand visible but frozen for a long time -> likely distracted / passed out
            return IDLE if now - self.last_motion > self.idle_after else PLAYING
        if now - self.last_face <= self.away_after:
            return IDLE      # person in frame, hands off the game
        return AWAY          # no hand, no face: player left
